package eggs;
public class Products {
	
		int=0
	}

}
